# Animated-login-form-Avatar

Made an animated SVG login avatar. I've seen a couple of these recently, but both were pre-illustrated and rendered frame-by-frame animations synced to the email input. I wanted to make one with live animations since it's a challenge to simulate the perspective and angles in real-time. Took a little brushing up on my trigonometry, but came up with a pretty believable solution.

<hr align="center" with="70%">

<div align="center"><a href="https://imgflip.com/gif/2pixk6"><img src="https://i.imgflip.com/2pixk6.gif" title="Animated-login-form-Avatar"/></a></div>



# Alisher Tog'ayev
  instagram - @sorry_but_im_monster<br>
  telegram   -   @wlbr
